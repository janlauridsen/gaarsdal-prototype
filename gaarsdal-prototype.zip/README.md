# Gaarsdal Hypnoterapi — Prototype

Denne repo indeholder en Next.js prototype med Tailwind + Sanity schemas. Følg instruktionerne i chatten for at deploye på Vercel.
